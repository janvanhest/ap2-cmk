﻿namespace LingoPartnerDomain.enums
{
  public enum MessageType
  {
    INFORMATION,
    WARNING,
    ERROR,
    CONFORMATION,
    SUCCES,
  }
}