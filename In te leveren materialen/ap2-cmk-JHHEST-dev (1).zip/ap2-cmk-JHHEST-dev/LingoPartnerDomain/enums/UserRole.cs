﻿namespace LingoPartnerDomain.enums;

public enum UserRole
{
  ADMIN,
  TEACHER,
  STUDENT
}