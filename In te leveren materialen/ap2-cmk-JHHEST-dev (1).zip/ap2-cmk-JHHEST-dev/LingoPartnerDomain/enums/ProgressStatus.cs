﻿namespace LingoPartnerDomain.enums;
using System.ComponentModel;
public enum ProgressStatus
{
  [Description("Not Started")]
  NOT_STARTED,
  [Description("In Progress")]
  IN_PROGRESS,
  [Description("Completed")]
  COMPLETED
}
